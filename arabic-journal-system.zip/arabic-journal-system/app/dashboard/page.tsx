import { getServerSession } from 'next-auth/next'
import { authOptions } from '../../lib/auth'
import prisma from '../../lib/prisma'
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card"
import { Button } from "../../components/ui/button"
import Link from 'next/link'

async function getDashboardData(userId: string) {
  const articles = await prisma.article.findMany({
    where: { authorId: userId },
    select: { id: true, title: true, status: true },
    orderBy: { updatedAt: 'desc' },
    take: 5
  })

  const reviews = await prisma.review.findMany({
    where: { reviewerId: userId },
    select: { id: true, article: { select: { title: true } }, status: true },
    orderBy: { updatedAt: 'desc' },
    take: 5
  })

  const notifications = await prisma.notification.findMany({
    where: { userId, read: false },
    orderBy: { createdAt: 'desc' },
    take: 5
  })

  return { articles, reviews, notifications }
}

export default async function Dashboard() {
  const session = await getServerSession(authOptions)
  if (!session || !session.user) {
    return <div>يرجى تسجيل الدخول للوصول إلى لوحة التحكم.</div>
  }

  const { articles, reviews, notifications } = await getDashboardData(session.user.id)

  return (
    <main className="container mx-auto mt-8 p-4">
      <h1 className="text-3xl font-bold mb-6">لوحة التحكم</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>المقالات الأخيرة</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {articles.map((article) => (
                <li key={article.id}>
                  <Link href={`/articles/${article.id}`} className="hover:underline">
                    {article.title} - {article.status}
                  </Link>
                </li>
              ))}
            </ul>
            <Button asChild className="mt-4">
              <Link href="/articles">عرض جميع المقالات</Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>المراجعات الأخيرة</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {reviews.map((review) => (
                <li key={review.id}>
                  {review.article.title} - {review.status}
                </li>
              ))}
            </ul>
            <Button asChild className="mt-4">
              <Link href="/reviews">عرض جميع المراجعات</Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>الإشعارات</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {notifications.map((notification) => (
                <li key={notification.id}>{notification.content}</li>
              ))}
            </ul>
            <Button asChild className="mt-4">
              <Link href="/notifications">عرض جميع الإشعارات</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </main>
  )
}

