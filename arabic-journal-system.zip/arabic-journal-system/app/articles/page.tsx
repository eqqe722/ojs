import { getServerSession } from 'next-auth/next'
import { authOptions } from '../../lib/auth'
import prisma from '../../lib/prisma'
import Header from '../components/Header'
import { Button } from "../../components/ui/button"
import Link from 'next/link'

async function getArticles() {
  const session = await getServerSession(authOptions)
  if (!session || !session.user) {
    return []
  }

  return prisma.article.findMany({
    where: {
      author: { email: session.user.email! },
    },
    orderBy: { createdAt: 'desc' },
  })
}

export default async function ArticlesPage() {
  const articles = await getArticles()

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <main className="container mx-auto mt-8 p-4">
        <h1 className="text-3xl font-bold mb-6">مقالاتي</h1>
        <Link href="/submit-article">
          <Button>تقديم مقالة جديدة</Button>
        </Link>
        <div className="mt-6 grid gap-6">
          {articles.map((article) => (
            <div key={article.id} className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-2xl font-semibold mb-2">{article.title}</h2>
              <p className="text-gray-600 mb-4">{article.abstract}</p>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500">الحالة: {article.status}</span>
                <Link href={`/articles/${article.id}`}>
                  <Button variant="outline">عرض التفاصيل</Button>
                </Link>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}

