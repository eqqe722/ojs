import { getServerSession } from 'next-auth/next'
import { authOptions } from '../../../lib/auth'
import prisma from '../../../lib/prisma'
import Header from '../../components/Header'
import { Button } from "../../../components/ui/button"
import Link from 'next/link'

async function getArticle(id: string) {
  const session = await getServerSession(authOptions)
  if (!session || !session.user) {
    return null
  }

  return prisma.article.findUnique({
    where: { id },
    include: {
      author: true,
      reviews: {
        include: { reviewer: true },
      },
    },
  })
}

export default async function ArticlePage({ params }: { params: { id: string } }) {
  const article = await getArticle(params.id)

  if (!article) {
    return <div>المقالة غير موجودة</div>
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <main className="container mx-auto mt-8 p-4">
        <h1 className="text-3xl font-bold mb-6">{article.title}</h1>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <p className="text-gray-600 mb-4">{article.abstract}</p>
          <div className="mb-4">
            <strong>الكلمات المفتاحية:</strong> {article.keywords.join(', ')}
          </div>
          <div className="mb-4">
            <strong>المؤلف:</strong> {article.author.name}
          </div>
          <div className="mb-4">
            <strong>الحالة:</strong> {article.status}
          </div>
          <div className="mb-4">
            <strong>الترخيص:</strong> {article.license}
          </div>
          <Link href={article.fileUrl!} target="_blank">
            <Button>عرض الملف الكامل</Button>
          </Link>
        </div>

        <h2 className="text-2xl font-bold mt-8 mb-4">المراجعات</h2>
        {article.reviews.length > 0 ? (
          <div className="space-y-4">
            {article.reviews.map((review) => (
              <div key={review.id} className="bg-white p-4 rounded-lg shadow-md">
                <p className="mb-2"><strong>المراجع:</strong> {review.reviewer.name}</p>
                <p className="mb-2"><strong>التقييم:</strong> {review.score}/5</p>
                <p><strong>التعليق:</strong> {review.content}</p>
              </div>
            ))}
          </div>
        ) : (
          <p>لا توجد مراجعات حتى الآن.</p>
        )}
      </main>
    </div>
  )
}

