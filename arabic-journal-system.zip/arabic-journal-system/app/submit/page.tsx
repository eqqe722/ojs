import Header from '../components/Header'

export default function SubmitArticle() {
  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <main className="container mx-auto mt-8 p-4">
        <h1 className="text-3xl font-bold mb-4">تقديم مقال جديد</h1>
        <form className="max-w-2xl mx-auto">
          <div className="mb-4">
            <label htmlFor="title" className="block mb-2">عنوان المقال</label>
            <input type="text" id="title" name="title" className="w-full p-2 border rounded" required />
          </div>
          <div className="mb-4">
            <label htmlFor="abstract" className="block mb-2">ملخص المقال</label>
            <textarea id="abstract" name="abstract" rows={4} className="w-full p-2 border rounded" required></textarea>
          </div>
          <div className="mb-4">
            <label htmlFor="keywords" className="block mb-2">الكلمات المفتاحية</label>
            <input type="text" id="keywords" name="keywords" className="w-full p-2 border rounded" required />
          </div>
          <div className="mb-4">
            <label htmlFor="file" className="block mb-2">ملف المقال (PDF)</label>
            <input type="file" id="file" name="file" accept=".pdf" className="w-full p-2 border rounded" required />
          </div>
          <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">تقديم المقال</button>
        </form>
      </main>
    </div>
  )
}

