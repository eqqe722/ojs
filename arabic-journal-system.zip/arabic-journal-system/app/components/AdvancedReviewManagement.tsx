'use client'

import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"

type Review = {
  id: string
  reviewerName: string
  articleTitle: string
  status: 'pending' | 'completed' | 'overdue'
  dueDate: string
}

export default function AdvancedReviewManagement() {
  const [reviews, setReviews] = useState<Review[]>([
    { id: '1', reviewerName: 'د. أحمد محمد', articleTitle: 'دراسة في الأدب العربي الحديث', status: 'pending', dueDate: '2023-08-15' },
    { id: '2', reviewerName: 'د. فاطمة علي', articleTitle: 'تحليل الخوارزميات في علوم الحاسب', status: 'completed', dueDate: '2023-08-10' },
    { id: '3', reviewerName: 'د. محمود حسن', articleTitle: 'النظريات الحديثة في الفيزياء الكمية', status: 'overdue', dueDate: '2023-08-05' },
  ])

  const handleRemindReviewer = (reviewId: string) => {
    console.log('تم إرسال تذكير للمراجع:', reviewId)
    // هنا يمكنك إضافة منطق إرسال التذكير
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">إدارة المراجعات</h2>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>المراجع</TableHead>
            <TableHead>عنوان المقال</TableHead>
            <TableHead>الحالة</TableHead>
            <TableHead>تاريخ الاستحقاق</TableHead>
            <TableHead>الإجراءات</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {reviews.map((review) => (
            <TableRow key={review.id}>
              <TableCell>{review.reviewerName}</TableCell>
              <TableCell>{review.articleTitle}</TableCell>
              <TableCell>
                <Badge variant={review.status === 'completed' ? 'default' : review.status === 'overdue' ? 'destructive' : 'secondary'}>
                  {review.status === 'pending' ? 'قيد الانتظار' : review.status === 'completed' ? 'مكتمل' : 'متأخر'}
                </Badge>
              </TableCell>
              <TableCell>{review.dueDate}</TableCell>
              <TableCell>
                <Button onClick={() => handleRemindReviewer(review.id)} disabled={review.status === 'completed'}>
                  إرسال تذكير
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

