'use client'

import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function BlindReviewSystem({ articleId }: { articleId: string }) {
  const [review, setReview] = useState('')
  const [score, setScore] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // هنا يتم إرسال المراجعة إلى الخادم
    console.log('تم إرسال المراجعة:', { articleId, review, score })
    // إعادة تعيين النموذج
    setReview('')
    setScore('')
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="review">المراجعة (لن يتم الكشف عن هويتك للمؤلف)</Label>
        <Textarea
          id="review"
          value={review}
          onChange={(e) => setReview(e.target.value)}
          placeholder="اكتب مراجعتك هنا..."
          className="h-40"
          required
        />
      </div>
      <div>
        <Label htmlFor="score">التقييم</Label>
        <Select value={score} onValueChange={setScore} required>
          <SelectTrigger>
            <SelectValue placeholder="اختر التقييم" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="1">1 - ضعيف جدًا</SelectItem>
            <SelectItem value="2">2 - ضعيف</SelectItem>
            <SelectItem value="3">3 - متوسط</SelectItem>
            <SelectItem value="4">4 - جيد</SelectItem>
            <SelectItem value="5">5 - ممتاز</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <Button type="submit">إرسال المراجعة</Button>
    </form>
  )
}

