'use client'

import Link from 'next/link'
import { useSession, signOut } from 'next-auth/react'
import { Button } from "@/components/ui/button"

export default function Header() {
  const { data: session } = useSession()

  return (
    <header className="bg-primary text-primary-foreground p-4">
      <nav className="container mx-auto flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold">نظام المجلة المفتوحة</Link>
        <ul className="flex space-x-4">
          {session ? (
            <>
              <li><Link href="/dashboard" className="hover:underline">لوحة التحكم</Link></li>
              <li><Link href="/submit-article" className="hover:underline">تقديم مقال</Link></li>
              <li><Button onClick={() => signOut()} variant="secondary">تسجيل الخروج</Button></li>
            </>
          ) : (
            <>
              <li><Link href="/login" className="hover:underline">تسجيل الدخول</Link></li>
              <li><Link href="/register" className="hover:underline">التسجيل</Link></li>
            </>
          )}
        </ul>
      </nav>
    </header>
  )
}

