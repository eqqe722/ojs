'use client'

import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis } from "recharts"

const data = [
  { month: "يناير", submissions: 13, publications: 10, rejections: 3 },
  { month: "فبراير", submissions: 15, publications: 11, rejections: 4 },
  { month: "مارس", submissions: 18, publications: 13, rejections: 5 },
  { month: "أبريل", submissions: 20, publications: 15, rejections: 5 },
  { month: "مايو", submissions: 22, publications: 16, rejections: 6 },
  { month: "يونيو", submissions: 25, publications: 18, rejections: 7 },
]

export default function AnalyticsDashboard() {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">لوحة التحكم التحليلية</h2>
      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <XAxis dataKey="month" />
            <YAxis />
            <Bar dataKey="submissions" name="التقديمات" fill="#8884d8" />
            <Bar dataKey="publications" name="المنشورات" fill="#82ca9d" />
            <Bar dataKey="rejections" name="الرفض" fill="#ffc658" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}

