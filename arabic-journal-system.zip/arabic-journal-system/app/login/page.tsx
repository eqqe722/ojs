import Header from '../components/Header'

export default function Login() {
  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <main className="container mx-auto mt-8 p-4">
        <h1 className="text-3xl font-bold mb-4">تسجيل الدخول</h1>
        <form className="max-w-md mx-auto">
          <div className="mb-4">
            <label htmlFor="email" className="block mb-2">البريد الإلكتروني</label>
            <input type="email" id="email" name="email" className="w-full p-2 border rounded" required />
          </div>
          <div className="mb-4">
            <label htmlFor="password" className="block mb-2">كلمة المرور</label>
            <input type="password" id="password" name="password" className="w-full p-2 border rounded" required />
          </div>
          <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">تسجيل الدخول</button>
        </form>
      </main>
    </div>
  )
}

