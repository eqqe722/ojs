'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"

export default function Register() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: '',
    institution: '',
    agreeTerms: false
  })
  const [error, setError] = useState('')
  const router = useRouter()

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }))
  }

  const handleSelectChange = (value: string) => {
    setFormData(prev => ({
      ...prev,
      role: value
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (formData.password !== formData.confirmPassword) {
      setError('كلمات المرور غير متطابقة')
      return
    }
    if (!formData.agreeTerms) {
      setError('يجب الموافقة على الشروط والأحكام')
      return
    }
    
    // Simulated API call
    console.log('Submitting registration:', formData)
    // In a real application, you would make an API call here
    // For now, we'll just simulate a successful registration
    router.push('/login')
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <main className="container mx-auto mt-8 p-4">
        <h1 className="text-3xl font-bold mb-6 text-center">التسجيل في نظام المجلة المفتوحة</h1>
        <form onSubmit={handleSubmit} className="max-w-md mx-auto space-y-4">
          <div>
            <Label htmlFor="name">الاسم الكامل</Label>
            <Input type="text" id="name" name="name" value={formData.name} onChange={handleChange} required />
          </div>
          <div>
            <Label htmlFor="email">البريد الإلكتروني</Label>
            <Input type="email" id="email" name="email" value={formData.email} onChange={handleChange} required />
          </div>
          <div>
            <Label htmlFor="password">كلمة المرور</Label>
            <Input type="password" id="password" name="password" value={formData.password} onChange={handleChange} required />
          </div>
          <div>
            <Label htmlFor="confirmPassword">تأكيد كلمة المرور</Label>
            <Input type="password" id="confirmPassword" name="confirmPassword" value={formData.confirmPassword} onChange={handleChange} required />
          </div>
          <div>
            <Label htmlFor="role">الدور</Label>
            <Select onValueChange={handleSelectChange}>
              <SelectTrigger>
                <SelectValue placeholder="اختر دورك" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="AUTHOR">مؤلف</SelectItem>
                <SelectItem value="REVIEWER">مراجع</SelectItem>
                <SelectItem value="EDITOR">محرر</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="institution">المؤسسة</Label>
            <Input type="text" id="institution" name="institution" value={formData.institution} onChange={handleChange} />
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox id="agreeTerms" name="agreeTerms" checked={formData.agreeTerms} onCheckedChange={(checked) => setFormData(prev => ({ ...prev, agreeTerms: checked as boolean }))} />
            <Label htmlFor="agreeTerms">أوافق على الشروط والأحكام</Label>
          </div>
          {error && <p className="text-red-500">{error}</p>}
          <Button type="submit" className="w-full">التسجيل</Button>
        </form>
      </main>
    </div>
  )
}

