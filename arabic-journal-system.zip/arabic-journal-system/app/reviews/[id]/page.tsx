import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import ReviewForm from '@/components/ReviewForm'

async function getReview(id: string, userId: string) {
  return prisma.review.findFirst({
    where: { id, reviewerId: userId },
    include: {
      article: {
        select: { title: true, abstract: true, author: { select: { name: true } } }
      }
    }
  })
}

export default async function ReviewPage({ params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session || !session.user) {
    return <div>يرجى تسجيل الدخول للوصول إلى صفحة المراجعة.</div>
  }

  const review = await getReview(params.id, session.user.id)

  if (!review) {
    return <div>لم يتم العثور على المراجعة.</div>
  }

  return (
    <main className="container mx-auto mt-8 p-4">
      <h1 className="text-3xl font-bold mb-6">مراجعة المقالة</h1>
      <Card>
        <CardHeader>
          <CardTitle>{review.article.title}</CardTitle>
        </CardHeader>
        <CardContent>
          <p>المؤلف: {review.article.author.name}</p>
          <p>الملخص: {review.article.abstract}</p>
          <p>الحالة: {review.status}</p>
          <p>تاريخ الاستحقاق: {review.dueDate.toLocaleDateString('ar-SA')}</p>
        </CardContent>
      </Card>

      <ReviewForm review={review} />
    </main>
  )
}

