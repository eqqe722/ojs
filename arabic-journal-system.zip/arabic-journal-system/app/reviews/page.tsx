import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from 'next/link'

async function getReviews(userId: string) {
  return prisma.review.findMany({
    where: { reviewerId: userId },
    include: {
      article: {
        select: { title: true, author: { select: { name: true } } }
      }
    },
    orderBy: { createdAt: 'desc' }
  })
}

export default async function ReviewsPage() {
  const session = await getServerSession(authOptions)
  if (!session || !session.user) {
    return <div>يرجى تسجيل الدخول للوصول إلى صفحة المراجعات.</div>
  }

  const reviews = await getReviews(session.user.id)

  return (
    <main className="container mx-auto mt-8 p-4">
      <h1 className="text-3xl font-bold mb-6">المراجعات</h1>
      <div className="grid gap-6">
        {reviews.map((review) => (
          <Card key={review.id}>
            <CardHeader>
              <CardTitle>{review.article.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p>المؤلف: {review.article.author.name}</p>
              <p>الحالة: {review.status}</p>
              <p>تاريخ الاستحقاق: {review.dueDate.toLocaleDateString('ar-SA')}</p>
              <Button asChild className="mt-4">
                <Link href={`/reviews/${review.id}`}>عرض التفاصيل</Link>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </main>
  )
}

