import './globals.css'
import { Amiri } from 'next/font/google'
import { Providers } from './providers'
import Header from './components/Header'

const amiri = Amiri({ subsets: ['arabic'], weight: ['400', '700'] })

export const metadata = {
  title: 'نظام المجلة المفتوحة',
  description: 'نظام مجلة مفتوحة باللغة العربية',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ar" dir="rtl">
      <body className={amiri.className}>
        <Providers>
          <Header />
          {children}
        </Providers>
      </body>
    </html>
  )
}

