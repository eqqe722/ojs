import Header from '../../components/Header'

export default function ReviewArticle({ params }: { params: { id: string } }) {
  // In a real application, you would fetch the article data based on the ID
  const article = {
    id: params.id,
    title: 'عنوان المقال للمراجعة',
    abstract: 'هذا هو ملخص المقال المقدم للمراجعة.',
    author: 'اسم الكاتب',
    status: 'قيد المراجعة',
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <main className="container mx-auto mt-8 p-4">
        <h1 className="text-3xl font-bold mb-4">مراجعة المقال</h1>
        <div className="bg-white p-6 rounded shadow">
          <h2 className="text-2xl font-semibold mb-2">{article.title}</h2>
          <p className="mb-2"><strong>الكاتب:</strong> {article.author}</p>
          <p className="mb-2"><strong>الحالة:</strong> {article.status}</p>
          <p className="mb-4"><strong>الملخص:</strong> {article.abstract}</p>
          <form>
            <div className="mb-4">
              <label htmlFor="comments" className="block mb-2">تعليقات المراجع</label>
              <textarea id="comments" name="comments" rows={4} className="w-full p-2 border rounded" required></textarea>
            </div>
            <div className="mb-4">
              <label htmlFor="decision" className="block mb-2">القرار</label>
              <select id="decision" name="decision" className="w-full p-2 border rounded" required>
                <option value="">اختر القرار</option>
                <option value="accept">قبول</option>
                <option value="revise">مراجعة</option>
                <option value="reject">رفض</option>
              </select>
            </div>
            <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">إرسال المراجعة</button>
          </form>
        </div>
      </main>
    </div>
  )
}

