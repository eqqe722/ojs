import { NextResponse } from 'next/server'
import { createUser, getUserByEmail } from '@/lib/db'

export async function POST(req: Request) {
  try {
    const { name, email, password, role, institution } = await req.json()

    const existingUser = await getUserByEmail(email)
    if (existingUser) {
      return NextResponse.json({ message: 'البريد الإلكتروني مستخدم بالفعل' }, { status: 400 })
    }

    await createUser(name, email, password, role, institution)

    return NextResponse.json({ message: 'تم التسجيل بنجاح' }, { status: 201 })
  } catch (error) {
    console.error('خطأ في التسجيل:', error)
    return NextResponse.json({ message: 'حدث خطأ أثناء التسجيل' }, { status: 500 })
  }
}

