import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '../../../lib/auth'
import prisma from '../../../lib/prisma'

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session || !session.user) {
    return NextResponse.json({ message: 'غير مصرح' }, { status: 401 })
  }

  try {
    const { title, abstract, keywords, content, fileUrl, license, language, journalId } = await req.json()

    const article = await prisma.article.create({
      data: {
        title,
        abstract,
        content,
        keywords: keywords.split(',').map((k: string) => k.trim()),
        fileUrl,
        license,
        language,
        status: 'SUBMITTED',
        author: { connect: { id: session.user.id } },
        journal: { connect: { id: journalId } },
      },
    })

    // Create a notification for the journal editors
    await prisma.notification.create({
      data: {
        content: `مقالة جديدة تم تقديمها: ${title}`,
        type: 'SYSTEM',
        user: { connect: { role: 'EDITOR' } },
      },
    })

    return NextResponse.json({ message: 'تم تقديم المقالة بنجاح', articleId: article.id }, { status: 201 })
  } catch (error) {
    console.error('خطأ في تقديم المقالة:', error)
    return NextResponse.json({ message: 'حدث خطأ أثناء تقديم المقالة' }, { status: 500 })
  }
}

