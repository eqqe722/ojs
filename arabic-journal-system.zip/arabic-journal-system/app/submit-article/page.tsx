'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useSession } from 'next-auth/react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"

export default function SubmitArticle() {
  const [formData, setFormData] = useState({
    title: '',
    abstract: '',
    keywords: '',
    content: '',
    fileUrl: '',
    license: '',
    language: 'ar',
    journalId: '',
  })
  const router = useRouter()
  const { data: session } = useSession()
  const { toast } = useToast()

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!session) {
      toast({
        title: "خطأ",
        description: "يجب تسجيل الدخول لتقديم مقالة",
        variant: "destructive",
      })
      return
    }

    try {
      const response = await fetch('/api/submit-article', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        toast({
          title: "تم بنجاح",
          description: "تم تقديم المقالة بنجاح",
        })
        router.push('/dashboard')
      } else {
        const data = await response.json()
        toast({
          title: "خطأ",
          description: data.message || 'حدث خطأ أثناء تقديم المقالة',
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "خطأ",
        description: 'حدث خطأ أثناء تقديم المقالة',
        variant: "destructive",
      })
    }
  }

  return (
    <main className="container mx-auto mt-8 p-4">
      <h1 className="text-3xl font-bold mb-6 text-center">تقديم مقالة جديدة</h1>
      <form onSubmit={handleSubmit} className="max-w-2xl mx-auto space-y-4">
        <div>
          <Label htmlFor="title">عنوان المقالة</Label>
          <Input type="text" id="title" name="title" value={formData.title} onChange={handleChange} required />
        </div>
        <div>
          <Label htmlFor="abstract">الملخص</Label>
          <Textarea id="abstract" name="abstract" value={formData.abstract} onChange={handleChange} required />
        </div>
        <div>
          <Label htmlFor="keywords">الكلمات المفتاحية (مفصولة بفواصل)</Label>
          <Input type="text" id="keywords" name="keywords" value={formData.keywords} onChange={handleChange} required />
        </div>
        <div>
          <Label htmlFor="content">محتوى المقالة</Label>
          <Textarea id="content" name="content" value={formData.content} onChange={handleChange} required className="h-64" />
        </div>
        <div>
          <Label htmlFor="fileUrl">رابط الملف (PDF)</Label>
          <Input type="url" id="fileUrl" name="fileUrl" value={formData.fileUrl} onChange={handleChange} required />
        </div>
        <div>
          <Label htmlFor="license">الترخيص</Label>
          <Select onValueChange={(value) => handleSelectChange('license', value)}>
            <SelectTrigger>
              <SelectValue placeholder="اختر الترخيص" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="CC BY">CC BY</SelectItem>
              <SelectItem value="CC BY-SA">CC BY-SA</SelectItem>
              
              <SelectItem value="CC BY-NC">CC BY-NC</SelectItem>
              <SelectItem value="CC BY-NC-SA">CC BY-NC-SA</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="language">اللغة</Label>
          <Select onValueChange={(value) => handleSelectChange('language', value)}>
            <SelectTrigger>
              <SelectValue placeholder="اختر اللغة" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ar">العربية</SelectItem>
              <SelectItem value="en">الإنجليزية</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="journalId">المجلة</Label>
          <Select onValueChange={(value) => handleSelectChange('journalId', value)}>
            <SelectTrigger>
              <SelectValue placeholder="اختر المجلة" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="journal1">المجلة الأولى</SelectItem>
              <SelectItem value="journal2">المجلة الثانية</SelectItem>
              <SelectItem value="journal3">المجلة الثالثة</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button type="submit" className="w-full">تقديم المقالة</Button>
      </form>
    </main>
  )
}

