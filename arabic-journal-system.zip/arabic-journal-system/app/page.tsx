import Link from 'next/link'
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-100">
      <main className="container mx-auto mt-8 p-4">
        <h1 className="text-4xl font-bold mb-6 text-center">مرحبًا بكم في نظام المجلة المفتوحة</h1>
        <p className="text-xl mb-8 text-center">منصة لنشر وإدارة الأبحاث العلمية باللغة العربية</p>
        
        <div className="flex justify-center space-x-4">
          <Link href="/register">
            <Button>التسجيل</Button>
          </Link>
          <Link href="/login">
            <Button variant="outline">تسجيل الدخول</Button>
          </Link>
        </div>

        <section className="mt-12">
          <h2 className="text-2xl font-semibold mb-4">أحدث المقالات</h2>
          <ul className="space-y-2">
            <li>
              <Link href="/articles/1" className="text-blue-600 hover:underline">
                دراسة حديثة في مجال الذكاء الاصطناعي
              </Link>
            </li>
            <li>
              <Link href="/articles/2" className="text-blue-600 hover:underline">
                تأثير التغير المناخي على الزراعة في الشرق الأوسط
              </Link>
            </li>
            <li>
              <Link href="/articles/3" className="text-blue-600 hover:underline">
                تطوير تقنيات جديدة في مجال الطاقة المتجددة
              </Link>
            </li>
          </ul>
        </section>
      </main>
    </div>
  )
}

