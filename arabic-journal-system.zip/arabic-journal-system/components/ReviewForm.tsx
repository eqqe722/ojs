'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"

export default function ReviewForm({ review }: { review: any }) {
  const [formData, setFormData] = useState({
    content: review.content || '',
    score: review.score?.toString() || '',
  })
  const router = useRouter()
  const { toast } = useToast()

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleSelectChange = (value: string) => {
    setFormData(prev => ({
      ...prev,
      score: value
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch(`/api/reviews/${review.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        toast({
          title: "تم بنجاح",
          description: "تم تقديم المراجعة بنجاح",
        })
        router.push('/reviews')
      } else {
        const data = await response.json()
        toast({
          title: "خطأ",
          description: data.message || 'حدث خطأ أثناء تقديم المراجعة',
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "خطأ",
        description: 'حدث خطأ أثناء تقديم المراجعة',
        variant: "destructive",
      })
    }
  }

  return (
    <form onSubmit={handleSubmit} className="mt-6 space-y-4">
      <div>
        <Label htmlFor="content">المراجعة</Label>
        <Textarea 
          id="content" 
          name="content" 
          value={formData.content} 
          onChange={handleChange} 
          required 
          className="h-40"
        />
      </div>
      <div>
        <Label htmlFor="score">التقييم</Label>
        <Select onValueChange={handleSelectChange} value={formData.score}>
          <SelectTrigger>
            <SelectValue placeholder="اختر التقييم" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="1">1 - ضعيف جدًا</SelectItem>
            <SelectItem value="2">2 - ضعيف</SelectItem>
            <SelectItem value="3">3 - متوسط</SelectItem>
            <SelectItem value="4">4 - جيد</SelectItem>
            <SelectItem value="5">5 - ممتاز</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <Button type="submit">تقديم المراجعة</Button>
    </form>
  )
}

