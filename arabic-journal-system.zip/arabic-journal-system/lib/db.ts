import prisma from './prisma'
import { hash } from 'bcryptjs'

export async function createUser(name: string, email: string, password: string, role: 'ADMIN' | 'EDITOR' | 'REVIEWER' | 'AUTHOR', institution?: string) {
  const hashedPassword = await hash(password, 12)
  return prisma.user.create({
    data: {
      name,
      email,
      password: hashedPassword,
      role,
      institution,
    },
  })
}

export async function getUserByEmail(email: string) {
  return prisma.user.findUnique({
    where: { email },
  })
}

export async function createArticle(title: string, abstract: string, content: string, authorId: string, keywords: string[]) {
  return prisma.article.create({
    data: {
      title,
      abstract,
      content,
      authorId,
      keywords,
    },
  })
}

export async function getArticleById(id: string) {
  return prisma.article.findUnique({
    where: { id },
    include: {
      author: true,
      reviews: {
        include: {
          reviewer: true,
        },
      },
    },
  })
}

export async function createReview(content: string, score: number, reviewerId: string, articleId: string, dueDate: Date) {
  return prisma.review.create({
    data: {
      content,
      score,
      reviewerId,
      articleId,
      dueDate,
    },
  })
}

export async function updateReviewStatus(id: string, status: 'PENDING' | 'COMPLETED' | 'OVERDUE') {
  return prisma.review.update({
    where: { id },
    data: { status },
  })
}

export async function createCitation(doi: string, apa: string, mla: string, chicago: string, harvard: string) {
  return prisma.citation.create({
    data: {
      doi,
      apa,
      mla,
      chicago,
      harvard,
    },
  })
}

export async function getCitationByDoi(doi: string) {
  return prisma.citation.findUnique({
    where: { doi },
  })
}

